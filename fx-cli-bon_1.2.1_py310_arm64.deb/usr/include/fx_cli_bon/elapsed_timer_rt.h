#pragma once
#include <chrono>
#include <string>
#include <atomic>
#include <cstdio>
#include <cmath>

class ElapsedTimerRT {
public:
    explicit ElapsedTimerRT(const std::string& name = "")
        : name_(name),
          start_time_(),
          count_(0),
          mean_(0.0),
          m2_(0.0),
          last_(0.0)
    {}

    ~ElapsedTimerRT() {
        // 소멸 시 자동으로 통계 출력
        if (count_.load(std::memory_order_relaxed) > 0) {
            std::printf("[RTTimer|%s] FINAL mean=%.3f ms, std=%.3f ms, last=%.3f ms, n=%zu\n",
                        name_.c_str(),
                        mean(),
                        stdev(),
                        latest(),
                        count_.load());
        }
    }
    
    inline void startTimer() noexcept {
        start_time_ = std::chrono::steady_clock::now();
    }

    inline void stopTimer() noexcept {
        auto   end_time = std::chrono::steady_clock::now();
        double x = std::chrono::duration<double, std::milli>(end_time - start_time_).count();

        // 마지막 측정값 갱신
        last_.store(x, std::memory_order_relaxed);

        // Welford online algorithm (단일 writer 가정)
        std::size_t n_prev = count_.load(std::memory_order_relaxed);
        std::size_t n      = n_prev + 1;

        double mean_prev = mean_.load(std::memory_order_relaxed);
        double m2_prev   = m2_.load(std::memory_order_relaxed);

        double delta  = x - mean_prev;
        double mean_new = mean_prev + delta / static_cast<double>(n);
        double delta2 = x - mean_new;
        double m2_new = m2_prev + delta * delta2;

        mean_.store(mean_new, std::memory_order_relaxed);
        m2_.store(m2_new, std::memory_order_relaxed);
        count_.store(n, std::memory_order_relaxed);
    }

    inline double latest() const noexcept {
        return last_.load(std::memory_order_relaxed);
    }

    inline double mean() const noexcept {
        std::size_t n = count_.load(std::memory_order_relaxed);
        if (n == 0) return 0.0;
        return mean_.load(std::memory_order_relaxed);
    }

    inline double stdev() const noexcept {
        std::size_t n = count_.load(std::memory_order_relaxed);
        if (n < 2) return 0.0;
        double m2 = m2_.load(std::memory_order_relaxed);
        double v  = m2 / static_cast<double>(n);  // 모집단 분산
        if (v < 0.0) v = 0.0;                     // 수치 안정성
        return std::sqrt(v);
    }

    inline void printLatest() const noexcept {
        std::printf("[RTTimer|%s] %.3f ms\n", name_.c_str(), latest());
    }

    inline void printStatistics() const noexcept {
        std::printf("[RTTimer|%s] mean=%.3f ms, std=%.3f ms\n",
                    name_.c_str(), mean(), stdev());
    }

private:
    std::string name_;
    std::chrono::steady_clock::time_point start_time_;

    // 전체 히스토리에 대한 통계 (메모리 O(1))
    std::atomic<std::size_t> count_;  // 샘플 개수
    std::atomic<double>      mean_;   // 평균
    std::atomic<double>      m2_;     // 편차 제곱합 (∑(x-mean)^2)
    std::atomic<double>      last_;   // 마지막 샘플 값
};
