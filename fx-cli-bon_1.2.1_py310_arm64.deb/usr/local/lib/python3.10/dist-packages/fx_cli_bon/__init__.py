"""fx_cli_bon Python package

This package exposes the high level FX motor controller client to Python.
It re-exports the C++ class `FxCli` from the compiled module `fx_cli_bon`.

Usage:

    import fx_cli_bon
    cli = fx_cli_bon.FxCli("192.168.10.10", 5101)
    cli.motor_start([1, 2])
    ...

"""

from .fx_cli_bon import FxCli

__all__ = ["FxCli"]
