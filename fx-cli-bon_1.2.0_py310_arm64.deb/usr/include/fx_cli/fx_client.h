#pragma once

#include <string>
#include <vector>
#include <cstdint>
#include <cstdio>
#include <pthread.h>
#include <sched.h>
#include <sys/mman.h>
#include <unordered_map>
#include <strings.h>

// RT thread / CPU affinity / mlock utility
static inline void set_thread_rt_and_affinity(int fifo_prio, int cpu_index) {
    pthread_t tid = pthread_self();

    // 1) Real-time scheduling
    if (fifo_prio > 0) {
        sched_param sp{};
        sp.sched_priority = fifo_prio;   // valid range usually 1~99
        if (pthread_setschedparam(tid, SCHED_FIFO, &sp) != 0) {
            perror("[WARN] pthread_setschedparam");
        }
    }

    // 2) CPU affinity
    if (cpu_index >= 0) {
        cpu_set_t cs;
        CPU_ZERO(&cs);
        CPU_SET(cpu_index, &cs);
        if (pthread_setaffinity_np(tid, sizeof(cs), &cs) != 0) {
            perror("[WARN] pthread_setaffinity_np");
        }
    }

    // 3) Prevent page faults
    if (mlockall(MCL_CURRENT | MCL_FUTURE) != 0) {
        perror("[WARN] mlockall");
    }
}

using FxCliMap = std::unordered_map<
    std::string,
    std::unordered_map<std::string, std::string>
>;

class FxCli {
public:
    /**
     * @brief Construct a UDP client and start the RX thread.
     * @param ip         Target IPv4 address
     * @param port       Target UDP port number
     * @param fifo_prio  RX thread FIFO priority (-1 or 0 to skip RT scheduling)
     * @param cpu_index  RX thread CPU affinity index (-1 to skip affinity)
     */
    FxCli(const std::string& ip = "192.168.10.10",
          uint16_t port = 5101,
          int fifo_prio = 85,
          int cpu_index = 4);

    FxCli(const FxCli&) = delete;
    FxCli& operator=(const FxCli&) = delete;

    ~FxCli();

    // -------------------------------------------------------------------------
    // MCU one-shot commands
    // -------------------------------------------------------------------------
    std::string mcu_ping();
    std::string mcu_whoami();

    bool mcu_reboot();

    /**
     * @brief Run MCU buzzer command.
     * @param duration_ms  Buzzer duration in milliseconds.
     * @param tone_hz      Tone frequency in Hz.
     * @param beep_hz      Beep frequency in Hz.
     */
    bool mcu_buz(uint32_t duration_ms,
                 uint32_t tone_hz,
                 uint32_t beep_hz);

    /**
     * @brief Clear MCU/driver diagnostic state.
     */
    bool diag_clear();

    // -------------------------------------------------------------------------
    // Motor one-shot commands
    // -------------------------------------------------------------------------
    bool motor_start(const std::vector<uint8_t>& ids);
    bool motor_stop(const std::vector<uint8_t>& ids);
    bool motor_estop(const std::vector<uint8_t>& ids);
    bool motor_setzero(const std::vector<uint8_t>& ids);

    // -------------------------------------------------------------------------
    // Realtime setpoint command
    // -------------------------------------------------------------------------
    bool operation_control(const std::vector<uint8_t>& ids,
                           const std::vector<float>& pos,
                           const std::vector<float>& vel,
                           const std::vector<float>& kp,
                           const std::vector<float>& kd,
                           const std::vector<float>& tau);

    // -------------------------------------------------------------------------
    // Request / status commands
    // -------------------------------------------------------------------------
    std::string req_raw(const std::vector<uint8_t>& ids);
    FxCliMap req(const std::vector<uint8_t>& ids);

    std::string status_raw();
    FxCliMap status();

    // -------------------------------------------------------------------------
    // RX ACK queue control
    // -------------------------------------------------------------------------
    void flush();
    void flush_tag(const char* tag_upper);

private:
    void send_cmd(const std::string& cmd);

    bool send_cmd_wait_ok_tag(const std::string& cmd,
                              const char* expect_tag,
                              int timeout_ms);

    bool send_cmd_wait_ok_tag(const std::string& cmd_base,
                              const char* expect_tag,
                              std::string& used_txid,
                              int timeout_ms);

    int timeout_ms_ = 1000;
    int timeout_ms_rt_ = 5;

    class UdpSocket;
    UdpSocket* socket_;
};
